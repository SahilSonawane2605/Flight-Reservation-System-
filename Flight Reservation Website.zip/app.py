from flask import Flask, render_template, request,session
from datetime import datetime
import threading
import webbrowser

app = Flask(__name__)
app.secret_key = "safar_secret_key"

class Flight:
    def __init__(self, flight_id, origin, destination, departure, price, date):
        self.flight_id = flight_id
        self.origin = origin
        self.destination = destination
        self.departure = departure
        self.price = price
        self.date = date

flights = [
    # Pune ↔ Mumbai
Flight("AI301", "Pune", "Mumbai", "06:00", 2000, "2025-10-18"),
Flight("AI302", "Pune", "Mumbai", "10:15", 1900, "2025-10-18"),
Flight("AI303", "Pune", "Mumbai", "17:30", 2400, "2025-10-18"),
Flight("AI304", "Mumbai", "Pune", "08:00", 2500, "2025-10-18"),
Flight("AI305", "Mumbai", "Pune", "14:10", 2300, "2025-10-18"),
Flight("AI306", "Mumbai", "Pune", "20:45", 2100, "2025-10-18"),

# Delhi ↔ Bangalore
Flight("AI307", "Delhi", "Bangalore", "07:00", 4000, "2025-10-18"),
Flight("AI308", "Delhi", "Bangalore", "13:30", 4200, "2025-10-18"),
Flight("AI309", "Delhi", "Bangalore", "19:15", 4400, "2025-10-18"),
Flight("AI310", "Bangalore", "Delhi", "06:20", 4100, "2025-10-18"),
Flight("AI311", "Bangalore", "Delhi", "12:50", 4300, "2025-10-18"),
Flight("AI312", "Bangalore", "Delhi", "18:40", 4500, "2025-10-18"),

# Chennai ↔ Hyderabad
Flight("AI313", "Chennai", "Hyderabad", "06:40", 2700, "2025-10-19"),
Flight("AI314", "Chennai", "Hyderabad", "12:15", 2900, "2025-10-19"),
Flight("AI315", "Chennai", "Hyderabad", "19:00", 3100, "2025-10-19"),
Flight("AI316", "Hyderabad", "Chennai", "08:30", 2600, "2025-10-19"),
Flight("AI317", "Hyderabad", "Chennai", "15:10", 2800, "2025-10-19"),
Flight("AI318", "Hyderabad", "Chennai", "21:20", 3000, "2025-10-19"),

# Delhi ↔ Mumbai
Flight("AI319", "Delhi", "Mumbai", "06:10", 3500, "2025-10-20"),
Flight("AI320", "Delhi", "Mumbai", "12:00", 3700, "2025-10-20"),
Flight("AI321", "Delhi", "Mumbai", "18:45", 3900, "2025-10-20"),
Flight("AI322", "Mumbai", "Delhi", "07:45", 3400, "2025-10-20"),
Flight("AI323", "Mumbai", "Delhi", "13:20", 3600, "2025-10 -20"),
Flight("AI324", "Mumbai", "Delhi", "19:50", 3800, "2025-10-20"),

# Kolkata ↔ Goa
Flight("AI325", "Kolkata", "Goa", "05:55", 4200, "2025-10-21"),
Flight("AI326", "Kolkata", "Goa", "11:10", 4400, "2025-10-21"),
Flight("AI327", "Kolkata", "Goa", "17:45", 4600, "2025-10-21"),
Flight("AI328", "Goa", "Kolkata", "07:15", 4100, "2025-10-21"),
Flight("AI329", "Goa", "Kolkata", "13:25", 4300, "2025-10-21"),
Flight("AI330", "Goa", "Kolkata", "19:40", 4500, "2025-10-21"),

# Pune ↔ Delhi
Flight("AI331", "Pune", "Delhi", "06:20", 3800, "2025-10-18"),
Flight("AI332", "Pune", "Delhi", "11:50", 4000, "2025-10-22"),
Flight("AI333", "Pune", "Delhi", "18:25", 4200, "2025-10-22"),
Flight("AI334", "Delhi", "Pune", "07:10", 3700, "2025-10-22"),
Flight("AI335", "Delhi", "Pune", "13:40", 3900, "2025-10-22"),
Flight("AI336", "Delhi", "Pune", "20:30", 4100, "2025-10-22"),

# Bangalore ↔ Goa
Flight("AI337", "Bangalore", "Goa", "05:45", 2600, "2025-10-23"),
Flight("AI338", "Bangalore", "Goa", "12:30", 2800, "2025-10-23"),
Flight("AI339", "Bangalore", "Goa", "18:10", 3000, "2025-10-23"),
Flight("AI340", "Goa", "Bangalore", "07:50", 2500, "2025-10-23"),
Flight("AI341", "Goa", "Bangalore", "14:15", 2700, "2025-10-23"),
Flight("AI342", "Goa", "Bangalore", "20:40", 2900, "2025-10-23"),

# Hyderabad ↔ Mumbai
Flight("AI343", "Hyderabad", "Mumbai", "06:35", 2600, "2025-10-24"),
Flight("AI344", "Hyderabad", "Mumbai", "12:05", 2800, "2025-10-24"),
Flight("AI345", "Hyderabad", "Mumbai", "19:00", 3000, "2025-10-24"),
Flight("AI346", "Mumbai", "Hyderabad", "08:00", 2700, "2025-10-24"),
Flight("AI347", "Mumbai", "Hyderabad", "14:20", 2900, "2025-10-24"),
Flight("AI348", "Mumbai", "Hyderabad", "21:10", 3100, "2025-10-24"),

# Chennai ↔ Pune
Flight("AI349", "Chennai", "Pune", "06:00", 3100, "2025-10-25"),
Flight("AI350", "Chennai", "Pune", "13:00", 3300, "2025-10-25"),
Flight("AI351", "Chennai", "Pune", "19:30", 3500, "2025-10-25"),
Flight("AI352", "Pune", "Chennai", "08:10", 3000, "2025-10-25"),
Flight("AI353", "Pune", "Chennai", "14:45", 3200, "2025-10-25"),
Flight("AI354", "Pune", "Chennai", "21:00", 3400, "2025-10-25"),

] 

@app.route("/", methods=["GET", "POST"])
def index():
    origin = destination = date = ""
    passengers = 1
    filtered = []
    show_flights = False


     #inputs
    if request.method == "POST":
        action = request.form.get("action")
        origin = request.form.get("origin", "").lower()
        destination = request.form.get("destination", "").lower()
        date = request.form.get("date", "")
        passengers = int(request.form.get("passengers", 1))

        filtered = flights.copy()

        # search filter
        if action == "search":
            filtered = [f for f in flights if
                        origin in f.origin.lower() and
                        destination in f.destination.lower() and
                        date == f.date]
            session["filtered"] = [(f.flight_id, f.origin, f.destination, f.departure, f.price, f.date) for f in filtered]
            show_flights = True

        #  flights
        elif action == "show_all":
            session["filtered"] = [(f.flight_id, f.origin, f.destination, f.departure, f.price, f.date) for f in flights]
            filtered = flights.copy()
            show_flights = True

        # Sort filtered flights
        elif action in ["sort_price", "sort_departure"]:
            raw = session.get("filtered", [])
            filtered = [Flight(*f) for f in raw]
            if action == "sort_price":
                filtered.sort(key=lambda f: f.price)
            else:
                filtered.sort(key=lambda f: f.departure)
            show_flights = True

    return render_template("index.html", flights=filtered,
                           origin=origin, destination=destination,
                           date=date, passengers=passengers,
                           show_flights=show_flights)
def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

if __name__ == '__main__':
    threading.Timer(1.5, open_browser).start()
    app.run(debug=True)  
